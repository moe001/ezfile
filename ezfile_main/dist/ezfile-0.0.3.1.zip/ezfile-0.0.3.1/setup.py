#!/usr/bin/env python

from setuptools import setup, find_packages

setup(name='ezfile',
      version='0.0.3.1',
      description='easy file-io',
      author='moe001',
      author_email='i@001.moe',
      url='https://github.com/moe001/ezfile',
      packages=find_packages(),
     )